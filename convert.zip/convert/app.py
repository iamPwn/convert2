from flask import Flask, request, jsonify, send_file
from yt_dlp import YoutubeDL
import os
import uuid

app = Flask(__name__)
DOWNLOAD_DIR = "downloads"

if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)

@app.route('/convert', methods=['POST'])
def convert():
    data = request.get_json()
    video_url = data.get('videoUrl')

    if not video_url:
        return jsonify({'error': 'Missing video URL'}), 400

    file_id = str(uuid.uuid4())
    output_template = os.path.join(DOWNLOAD_DIR, f'{file_id}.%(ext)s')

    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': output_template,
        'postprocessors': [{
            'key': 'FFmpegExtractAudio',
            'preferredcodec': 'mp3',
            'preferredquality': '192',
        }],
        'quiet': True
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])

        mp3_file = os.path.join(DOWNLOAD_DIR, f'{file_id}.mp3')
        if not os.path.exists(mp3_file):
            return jsonify({'error': 'Conversion failed'}), 500

        return jsonify({
            'downloadUrl': f'/download/{file_id}'
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download/<file_id>', methods=['GET'])
def download(file_id):
    mp3_path = os.path.join(DOWNLOAD_DIR, f'{file_id}.mp3')
    if os.path.exists(mp3_path):
        return send_file(mp3_path, as_attachment=True)
    return 'File not found', 404

if __name__ == '__main__':
    app.run(debug=True)
